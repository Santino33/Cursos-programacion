package ejercicios;

public interface CocheCRUD {
    public void save();
    public void findAll();
    public void delete();
}
